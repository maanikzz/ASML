package com.asml.work;

import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Robot;

import javax.swing.JFrame;
import java.awt.Toolkit;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class GUI {

	private JFrame frmAsml;
	
	private String degrees[]={"DN_0Degree","DN_90Degree","DN_180Degree","DN_270Degree",
			"UP_0Degree","UP_90Degree","UP_180Degree","UP_270Degree"};
	
	private String file_path = "null";
//	private String file_path = "D:\\LokeshKosuri\\ASML_Image_Data\\";
			//"/home/manikandan/Downloads/ASML/
	
	
	private String fileName;
	private JFileChooser fileChooser;
	private String choosertitle;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frmAsml.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAsml = new JFrame();
		frmAsml.setIconImage(Toolkit.getDefaultToolkit().getImage(GUI.class.getResource("/com/asml/work/scissor.png")));
		frmAsml.getContentPane().setBackground(UIManager.getColor("Panel.background"));
		frmAsml.setFont(new Font("DejaVu Sans", Font.BOLD, 17));
		frmAsml.setTitle("ASML Snipping Tool");
		frmAsml.setBackground(Color.BLUE);
		frmAsml.setBounds(100, 100, 494, 222);
		frmAsml.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAsml.getContentPane().setLayout(null);
		
		JLabel lblSaveImageAs = new JLabel("Save screenshot as");
		lblSaveImageAs.setHorizontalAlignment(SwingConstants.CENTER);
		lblSaveImageAs.setBounds(119, 84, 139, 23);
		frmAsml.getContentPane().add(lblSaveImageAs);
		
		JLabel lblFileSavedSuccesful = new JLabel("Recent Activity :");
		lblFileSavedSuccesful.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		lblFileSavedSuccesful.setBounds(12, 144, 123, 15);
		frmAsml.getContentPane().add(lblFileSavedSuccesful);
		
		JLabel lblNewLabel = new JLabel("Nil");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 14));
		lblNewLabel.setForeground(new Color(51, 204, 102));
		lblNewLabel.setBounds(151, 144, 319, 15);
		frmAsml.getContentPane().add(lblNewLabel);
		
		JLabel lblSelectFromSettings = new JLabel("Browse from Settings");
		lblSelectFromSettings.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		lblSelectFromSettings.setBounds(151, 12, 313, 15);
		frmAsml.getContentPane().add(lblSelectFromSettings);
		
		
		JComboBox comboBox = new JComboBox(degrees);
		comboBox.setBackground(UIManager.getColor("ComboBox.buttonBackground"));
		comboBox.setBounds(272, 84, 210, 23);
		frmAsml.getContentPane().add(comboBox);
//---------------------------------------------------------------------------------------------------------		
		
		JMenuBar menuBar = new JMenuBar();
		frmAsml.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Settings");
		mnNewMenu.setHorizontalAlignment(SwingConstants.CENTER);
		mnNewMenu.setIcon(new ImageIcon(GUI.class.getResource("/com/asml/work/favicon.png")));
		menuBar.add(mnNewMenu);
		JMenuItem mntmNewMenuItem = new JMenuItem("Storage Location");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fileChooser = new JFileChooser();
	            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	            File file = null;
	            int option = fileChooser.showOpenDialog(frmAsml);
	            if(option == JFileChooser.APPROVE_OPTION){
	               file = fileChooser.getSelectedFile().getAbsoluteFile();
	               System.out.println("Folder Selected: " + file.getName());
	               System.out.println(file);
//	               label.setText("Folder Selected: " + file.getName());
	            }
	            else{
//	               label.setText("Open command canceled");
	            	System.out.println("Open command canceled");
	            }
	            
	            file_path=file.toString()+"\\";
	            System.out.println(file_path);
	            lblSelectFromSettings.setText(file_path);
	            
	            
	         }
		});
		
		
		mntmNewMenuItem.setSelected(true);
		mntmNewMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
		mnNewMenu.add(mntmNewMenuItem);
		
		
		
		
//------------------------------------------------------------------------------------------------		
		
		JButton btnNewButton = new JButton("Capture");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (file_path =="null") {
					System.out.println("please select location");
					JOptionPane.showMessageDialog(frmAsml, "Please select storage location (ctrl+s) ",
                            "WARNING", JOptionPane.WARNING_MESSAGE);
					
				}
				
				else {
				
				   try {
					   
		    		String result =comboBox.getItemAt(comboBox.getSelectedIndex()).toString();
		    		frmAsml.setState(JFrame.ICONIFIED);
		    		
		    		Thread.sleep(1000);
		            
					Robot robot= new Robot();
					String format = "PNG";
					fileName= result +"."+ format;	
					
					Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
					BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
					System.out.println("Bufered image loaded");
					System.out.println(file_path);
					ImageIO.write(screenFullImage, "PNG", new File(file_path+ fileName));
					System.out.println("Screenshot taken " + fileName);
//					lblFileSavedSuccesful.setForeground(null););
					
					lblNewLabel.setForeground(new Color(255, 0, 51));
					lblNewLabel.setText( "Saved as "+ fileName );
//					l3.setText("click capture for new image");
				
				   }
				   
				
				catch (Exception exception) {
					exception.printStackTrace();
					// TODO: handle exception
				}
			}
				
				
				
			}
		});
		btnNewButton.setBounds(378, 119, 104, 23);
		frmAsml.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Stotage Location :");
		lblNewLabel_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 12, 148, 15);
		frmAsml.getContentPane().add(lblNewLabel_1);
		
		
		

	}
}
